<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Blog - Contacto</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="imagenes/logo.png" alt="Logo del Blog" class="logo">
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="about.php">Acerca de</a></li>
                    <li><a href="contacto.php" class="active">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="contact">
            <h1>Contacto</h1>
            
            <div class="contact-container">
                <div class="contact-info">
                    <h2>Información de Contacto</h2>
                    <p><strong>Email:</strong> info@miblog.com</p>
                    <p><strong>Teléfono:</strong> +1 234 567 890</p>
                    <p><strong>Dirección:</strong> Ciudad, País</p>
                    
                    <div class="social-links">
                        <h3>Síguenos en:</h3>
                        <a href="#" class="social-link">Twitter</a>
                        <a href="#" class="social-link">Facebook</a>
                        <a href="#" class="social-link">Instagram</a>
                    </div>
                </div>
                
                <div class="contact-form">
                    <h2>Envíanos un Mensaje</h2>
                    
                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        // Procesar el formulario
                        $nombre = htmlspecialchars($_POST['nombre']);
                        $email = htmlspecialchars($_POST['email']);
                        $mensaje = htmlspecialchars($_POST['mensaje']);
                        
                        // Aquí normalmente enviarías el email o guardarías en base de datos
                        echo "<div class='alert success'>¡Gracias por tu mensaje, $nombre! Te responderemos pronto.</div>";
                    }
                    ?>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" id="nombre" name="nombre" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="mensaje">Mensaje:</label>
                            <textarea id="mensaje" name="mensaje" rows="5" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn">Enviar Mensaje</button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Mi Blog. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>