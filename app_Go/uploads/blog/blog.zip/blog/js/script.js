// JavaScript para funcionalidades del blog

document.addEventListener('DOMContentLoaded', function() {
    console.log('Blog cargado correctamente');
    
    // Smooth scroll para enlaces internos
    const smoothScroll = function() {
        const links = document.querySelectorAll('a[href^="#"]');
        
        for (const link of links) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        }
    };
    
    // Validación adicional del formulario de contacto
    const contactFormValidation = function() {
        const form = document.querySelector('.contact-form form');
        if (!form) return;
        
        form.addEventListener('submit', function(e) {
            const nombre = document.getElementById('nombre').value.trim();
            const email = document.getElementById('email').value.trim();
            const mensaje = document.getElementById('mensaje').value.trim();
            
            // Validación básica
            if (nombre.length < 2) {
                e.preventDefault();
                alert('Por favor, ingresa un nombre válido (mínimo 2 caracteres)');
                return;
            }
            
            if (!isValidEmail(email)) {
                e.preventDefault();
                alert('Por favor, ingresa un email válido');
                return;
            }
            
            if (mensaje.length < 10) {
                e.preventDefault();
                alert('Por favor, escribe un mensaje más detallado (mínimo 10 caracteres)');
                return;
            }
        });
    };
    
    // Función para validar email
    const isValidEmail = function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };
    
    // Efecto de fade in para las publicaciones
    const fadeInPosts = function() {
        const posts = document.querySelectorAll('.post');
        
        posts.forEach((post, index) => {
            post.style.opacity = '0';
            post.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                post.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                post.style.opacity = '1';
                post.style.transform = 'translateY(0)';
            }, index * 200);
        });
    };
    
    // Contador de visitas (simulado)
    const visitCounter = function() {
        let visits = localStorage.getItem('blogVisits');
        
        if (!visits) {
            visits = 1;
        } else {
            visits = parseInt(visits) + 1;
        }
        
        localStorage.setItem('blogVisits', visits);
        console.log(`Visitas a este blog: ${visits}`);
    };
    
    // Inicializar todas las funcionalidades
    smoothScroll();
    contactFormValidation();
    fadeInPosts();
    visitCounter();
    
    // Efecto hover mejorado para tarjetas
    const cards = document.querySelectorAll('.post, .contact-info, .contact-form');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        });
    });
});