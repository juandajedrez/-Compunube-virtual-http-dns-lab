<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Blog - Acerca de</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="imagenes/logo.png" alt="Logo del Blog" class="logo">
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="about.php" class="active">Acerca de</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="about">
            <h1>Acerca de Mi Blog</h1>
            
            <div class="about-content">
                <h2>Nuestra Misión</h2>
                <p>Este blog fue creado con la finalidad de compartir conocimientos, experiencias y reflexiones sobre diversos temas de interés.</p>
                
                <h2>¿Qué encontrarás aquí?</h2>
                <ul>
                    <li>Artículos sobre desarrollo web</li>
                    <li>Tutoriales de programación</li>
                    <li>Reflexiones personales</li>
                    <li>Noticias del mundo tech</li>
                </ul>
                
                <h2>El Creador</h2>
                <p>Soy un apasionado del desarrollo web y la programación. Me encanta aprender nuevas tecnologías y compartir lo que voy aprendiendo con la comunidad.</p>
                
                <blockquote>
                    "El conocimiento es la única cosa que no puedes gastar, solo puedes compartirlo."
                </blockquote>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Mi Blog. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>