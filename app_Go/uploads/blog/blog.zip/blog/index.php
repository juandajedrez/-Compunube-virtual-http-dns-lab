<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Blog - Inicio</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="imagenes/logo.png" alt="Logo del Blog" class="logo">
            <nav>
                <ul>
                    <li><a href="index.php" class="active">Inicio</a></li>
                    <li><a href="about.php">Acerca de</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="hero">
            <h1>Bienvenido a Mi Blog</h1>
            <p>Un espacio para compartir ideas y experiencias</p>
        </section>

        <section class="posts">
            <h2>Últimas Publicaciones</h2>
            
            <?php
            // Simulación de posts (en un caso real vendrían de una base de datos)
            $posts = [
                [
                    'titulo' => 'Primera publicación',
                    'contenido' => 'Este es el contenido de mi primera publicación en el blog...',
                    'fecha' => '2025-11-03',
                    'autor' => 'Desconocido'
                ],
                [
                    'titulo' => 'Aprendiendo ',
                    'contenido' => 'PHP es un lenguaje fantástico para desarrollo web...',
                    'fecha' => '2025-11-01',
                    'autor' => 'Desconodido'
                ],
                [
                    'titulo' => 'Introducción a Python',
                    'contenido' => 'Python trae muchas características interesantes...',
                    'fecha' => '2025-11-05',
                    'autor' => 'Desconocido'
                ]
            ];

            foreach ($posts as $post) {
                echo "
                <article class='post'>
                    <h3>{$post['titulo']}</h3>
                    <p class='post-meta'>Publicado el {$post['fecha']} por {$post['autor']}</p>
                    <p>{$post['contenido']}</p>
                    <a href='#' class='read-more'>Leer más</a>
                </article>
                ";
            }
            ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Mi Blog. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>